export const COSIGNER_BASE_URL = 'https://rpc.walletconnect.org/v1/sessions'
